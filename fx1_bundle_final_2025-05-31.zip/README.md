# 📦 FX1 – Ensemble de fichiers certifiés (Affaire Raitano vs Temmerman)

Ce dépôt contient un lot complet de fichiers HTML optimisés selon le modèle **FX1-Ultra++**, version V3.3.2plus, destiné à la publication GitHub Pages et à l’archivage juridique.

## 📄 Contenu inclus

- fx1opt-index.html – Page d’introduction
- fx1opt-certification.html – Preuve de conformité
- fx1_ultime_bascule.html – Page d’inversion stratégique
- fx1opt-mediatique.html – Exposé documentaire
- fx1opt-mentions-legales.html – Mentions RGPD / CEDH
- fx1opt-pourquoi.html – Motifs exposés
- robots.txt – Indexation autorisée
- sitemap.xml – Référencement SEO
- fx1-certification.txt – Résumé technique & hash
- README.md – Ce fichier

## 📜 Base juridique

- RGPD art. 6.1.e-f
- AI Act (publication documentaire)
- Convention européenne des droits de l’homme – Art. 10
- Accessibilité WCAG 2.1 – niveau AA

## 🔐 Hash SHA-256

Voir le fichier `fx1-certification.txt`.

## ✅ Utilisation

Ces fichiers sont conçus pour être publiés **tels quels** sur GitHub Pages à l’adresse :
`https://raitano-temmerman.github.io/[nom-dépôt]/`

Licence : CC BY 4.0 – Attribution requise.
