# 🛡️ Dépôt FX1 – Certification juridique trilingue

Ce dépôt contient l'intégralité du site web FX1, structuré et validé selon le protocole **FX1 – ULTIMA++**, dans les trois langues officielles :

- 🇫🇷 Français
- 🇳🇱 Néerlandais
- 🇬🇧 Anglais

## 📂 Contenu du dépôt

Chaque fichier HTML est :

- Conforme RGPD (art. 6.1 e-f), CEDH (art. 10), AI Act et eIDAS
- Certifié avec une **empreinte SHA-512** disponible dans le fichier `.sha512`
- Accessible (WCAG 2.1 AAA), sans CDN ni ressource externe
- Intégré avec des balises sémantiques OpenGraph et JSON-LD

## 🗂️ Arborescence principale

- `index.html`, `index-en.html`, `index-nl.html` : page d’accueil dans chaque langue
- `pourquoi-*.html`, `bascule-*.html`, `mediatique-*.html` : sections thématiques
- `mentions-legales-*.html` : base juridique
- `sitemap.xml` : couverture SEO complète
- `googlexxxx.html` : fichier de validation Google Search Console
- `*.sha512` : empreintes d’intégrité de chaque page

## 🧾 Attestation FX1

Voir le fichier :
- `Attestation_FX1_Ultra_V3.3.2plus_20250530.pdf`

---

© 2025 – Documentation publiée sous licence Creative Commons BY-NC-ND 4.0
