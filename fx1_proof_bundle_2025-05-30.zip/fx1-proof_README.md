
# Dossier de preuve – fx1-proof

Ce dossier contient les éléments techniques permettant de vérifier l'intégrité, l’authenticité et la traçabilité des fichiers publiés sur le site judiciaire FX1 (affaire RAITANO vs TEMMERMAN, 2025).

---

## 🔐 1. Empreinte cryptographique (SHA-256)

Le fichier `fx1_site_2025-05-30_FINAL_SHA256.txt` contient l’empreinte SHA-256 de l’archive officielle du site :

- **Nom de l’archive** : `fx1_site_2025-05-30_FINAL.zip`
- **Hash SHA-256** :  
  `e4cf57c9573b1b609c7b1b1274171c5e1129fefbc764fd4b7e038d2d84f5a31c`

Ce hash permet de vérifier que l’archive n’a pas été modifiée depuis sa publication, en ligne avec les principes de transparence documentaire et de preuve numérique opposable.

---

## 🧾 2. Fichiers de métadonnées associés

Les fichiers suivants sont fournis pour auditer, traduire ou réutiliser les pages HTML FX1 en toute conformité :

- `fx1trad-certification-fr.json`
- `fx1trad-mediatique-fr.json`
- `fx1trad-index-fr.json`
- `fx1certification-bascule-fr.json`
- `fx1trad-README-fr.md`
- `fx1trad-certification-fr-README.md`

---

## ⚖️ 3. Cadre juridique applicable

Ce mécanisme de preuve s’appuie sur :
- L’article 6.1.f du **RGPD** (intérêt légitime à conserver des preuves),
- L’article 10 de la **CEDH** (liberté d’expression),
- Les principes de **conservation probatoire** valables en droit belge et européen.

---

## 📌 4. Vérification

Pour vérifier l’intégrité de l’archive :
1. Téléchargez le fichier `fx1_site_2025-05-30_FINAL.zip`
2. Calculez son empreinte SHA-256 (ex. : `shasum -a 256 <nom_du_fichier>`)
3. Comparez avec la valeur du fichier `.txt`

---

## 🗂️ Structure recommandée

Placez ce dossier `/fx1-proof/` à la racine du dépôt GitHub ou dans `/docs/` si vous souhaitez éviter son indexation par défaut.

---

© 2025 – Raitano, documentation probatoire FX1 – générée et structurée par IA.
